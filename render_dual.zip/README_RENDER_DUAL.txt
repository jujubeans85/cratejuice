CJ BoltFlex — Render Dual Boot (Gunicorn + Uvicorn)

1. Unzip this at your project root (overwrite render.yaml)
2. Commit & push:
   git add render.yaml
   git commit -m "forge: render dual boot"
   git push
3. In Render → Deploy latest commit

Logs will show one of:
  🚀 Launching with Gunicorn (prod mode)
  💡 Gunicorn not found — using Uvicorn (dev mode)

Result: runs anywhere, every time.
PLUR ⚡
