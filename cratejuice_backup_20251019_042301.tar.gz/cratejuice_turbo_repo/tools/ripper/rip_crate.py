# stub ripper
