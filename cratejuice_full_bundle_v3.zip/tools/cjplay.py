#!/usr/bin/env python3
print('cjplay placeholder; use previous full version if needed')
