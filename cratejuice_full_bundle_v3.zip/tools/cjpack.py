#!/usr/bin/env python3
print('cjpack placeholder; use previous full version if needed')
